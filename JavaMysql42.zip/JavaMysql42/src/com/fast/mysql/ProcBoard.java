package com.fast.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProcBoard {

	Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		ProcBoard ladder = new ProcBoard();
		ladder.jjang();
	}

	static private String SQL_NAME = "yungseokzz";
	static private String SQL_ID = "root";
	static private String SQL_PW = "root";

	Connection con = null;
	Statement st = null;
	ResultSet result = null;
//	PreparedStatement pstmt = null;
	
	public void jjang() {
		Display.showTitle();

		dblocation();

		loop: 
			while (true) {

			Display.showMainMenu();
			System.out.println("입력: ");

			String qwe = sc.next();

			switch (qwe) {

			case "1":
				System.out.println("==========================================");
				System.out.println("================= 글리스트 ==================");
				System.out.println("글번호 글제목 작성자id 작성시간 조회수 글내용");
				try {
					
					result = st.executeQuery("select * from board");
//					pstmt = con.prepareStatement
					
					while (result.next()) {
						String no = result.getString("b_no");
						String title = result.getString("b_title");
						String id = result.getString("b_id");
						String datetime = result.getString("b_datetime");
						int hit = result.getInt("b_hit");
						String text = result.getString("b_text");
						System.out.println(no + " " + title + " " + id + " " + datetime + " " + hit + " " + text);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;

			case "2":
				System.out.println("읽을 번호를 입력해주세요:");
				
				String read = sc.next();
				try {
					result = st.executeQuery("select * from board where b_no =" + read);
					result.next();
					String title = result.getString("b_title");
					String text = result.getString("b_text");
					System.out.println("제목: " + title);
					System.out.println("내용: " + text);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;

			case "3":
				System.out.println("제목을 입력해주세요:");
				String title = sc.next();
				System.out.println("내용을 입력해주세요:");
				String content = sc.next();
				System.out.println("id를 입력해주세요:");
				String id = sc.next();
				try {
					st.executeUpdate("insert into board (b_title,b_id,b_datetime,b_hit,b_text)" + " values ('" + title
							+ "','" + id + "',now(),0,'" + content + "')");
					System.out.println("등록 완료");
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;

			case "4":
				System.out.println("삭제할 번호를 입력해주세요:");
				String del = sc.next();
				dbExecuteUpdate("delete from board where b_no=" + del);
				break;

			case "5":
				System.out.println("수정할 번호를 입력해주세요:");
				String No = sc.next();
				System.out.println("제목을 입력해주세요:");
				String Title = sc.next();
				System.out.println("id를 입력해주세요:");
				String Id = sc.next();
				System.out.println("내용을 입력해주세요:");
				String Content = sc.next();
				System.out.println("조회수 변경");
				String Hit = sc.next();
				dbExecuteUpdate("update board set b_title='" + Title + "',b_id='" + Id
						+ "',b_datetime=now(),b_text='" + Content + "', b_hit='" + 
						Hit + "' where b_no=" + No);
				break;

			case "0":
				break;

			case "e":
				System.out.println("프로그램종료");
				break loop;

			default:
				System.out.println("다른거클릭X");

			}
		}
	}

	private void dblocation() {
		try {
		Connection 
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + SQL_NAME, SQL_ID, SQL_PW);
		st = con.createStatement();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("처리된 행 수:" + resultCount);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
