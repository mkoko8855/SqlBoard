/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module JavaMysql42 {
	requires java.sql;
}